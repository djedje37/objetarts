<?php
$dsn = 'mysql:host=localhost;dbname=objetarts';
$user = 'root';
$password = '';

try {
    $dbh = new PDO('mysql:host=localhost;dbname= objetarts', 'root', '');
} catch (PDOException $e) {
    echo 'Connexion échouée : ' . $e->getMessage();
}

?>

<!DOCTYPE html>S
<html lang="fr">
<meta charset="utf-8">


    <head>
        <title>Accueil</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <!-- Font-Awesome -->
        <link href="Font-Awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- My style -->
        <link href="css/style.css" rel="stylesheet" media="screen">
    <link href= "accueil.css" rel="stylesheet"  >

    </head>
     <?php
         include 'barnav.php';
        ?>






<form action="accueil.php" method="post">
Nom: <input type="text" name="nom"><br>
Prenom: <input type="text" name="prenom"><br>
Age: <input type="text" name="age"><br>
Genre:
<input type="radio" name="genre" value="femme">Femme
<input type="radio" name="genre" value="homme">Homme<br>
mail: <input type="text" name="mail"><br>
mot de passe : <input type="text" name="mot de passe"><br>
Telephone: <input type="text" name="telephone"><br>
Pays: <input type="text" name="pays"><br>
Ville: <input type="text" name="ville"><br>

<input type="submit">
</form>



