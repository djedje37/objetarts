<?php
$dsn = 'mysql:host=localhost;dbname=objetarts';
$user = 'root';
$password = '';

try {
    $dbh = new PDO('mysql:host=localhost;dbname= objetarts', 'root', '');
} catch (PDOException $e) {
    echo 'Connexion échouée : ' . $e->getMessage();
}

?>
<!DOCTYPE html>S
<html lang="fr">
<meta charset="utf-8">


    <head>
        <title>Accueil</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- Bootstrap -->
        <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
        <!-- Font-Awesome -->
        <link href="Font-Awesome/css/font-awesome.min.css" rel="stylesheet">
        <!-- My style -->
        <link href="css/style.css" rel="stylesheet" media="screen">
    	<link href= "accueil.css" rel="stylesheet"  >

    </head>
      <?php
 		 include 'barnav.php';
  		?>



		 <section id="content">
              <form action="accueil.php" method="post">
                Name: <input type="text" name="email"><br>
                E-mail: <input type="password" name="mot de passe"><br>
                <input type="submit">
               	 </form>



        </section>
